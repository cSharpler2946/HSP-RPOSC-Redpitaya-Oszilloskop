#pragma once

#include <string>
using namespace std;

struct SRDDecoderDefintion
{
    string id;
    string name;
    string longname;
    string desc;
};
