using namespace std

void startAcq()
list<double> getData()
Acquirer(int sampleRate, list<string> channels, list<string> decimation, list<string> gains)
void ChangeSampleRate(int rate)
