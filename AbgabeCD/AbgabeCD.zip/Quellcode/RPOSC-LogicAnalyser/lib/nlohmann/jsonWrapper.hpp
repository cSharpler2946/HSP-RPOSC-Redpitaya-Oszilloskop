#pragma once

#define NDEBUG

#include <cassert>
#define JSON_ASSERT(x) assert(x)
#include "json.hpp"