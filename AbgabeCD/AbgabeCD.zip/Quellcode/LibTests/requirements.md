# Requirements for buidling test project using libsigrok and libsigrokdecode
## Fedroa (dnf):
- libsigrok libsigrok-devel
- libsigrokdecode libsigrokdecode-devel
- glib2 glib2-devel

## Mint/Ubuntu (apt):
- libsigrok4 libsigrok-dev
- libsigrokdecode4 libsigrokdecode-dev
- libglib2.0-0 libglib2.0-dev

# Notes:
- Location of decoders: "/usr/share/libsigrokdecode/decoders"